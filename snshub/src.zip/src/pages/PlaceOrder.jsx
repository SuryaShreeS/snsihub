// src/pages/PlaceOrder.js
import React, { useState } from 'react';
import { Container, Typography, Button, Box } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';

const PlaceOrder = () => {
    const location = useLocation();
    const navigate = useNavigate(); // Initialize useNavigate
    const { cart } = location.state || {}; // Get cart items from the state

    const [orderPlaced, setOrderPlaced] = useState(false); // State to track if the order is placed

    const handlePayment = (paymentMethod) => {
        // Logic to handle payment
        console.log(`Payment method selected: ${paymentMethod}`);
        
        // Simulate order placement
        setOrderPlaced(true); // Set orderPlaced to true when the order is placed
    };

    const handleReturnHome = () => {
        navigate('/'); // Navigate back to the home page
    };

    return (
        <Container maxWidth="lg">
            <Typography variant="h4" gutterBottom>
                Place Your Order
            </Typography>
            {orderPlaced ? (
                <Box mt={4}>
                    <Typography variant="h6" color="green">
                        Order placed successfully!
                    </Typography>
                    <Button variant="contained" color="primary" onClick={handleReturnHome} sx={{ mt: 2 }}>
                        Return to Home
                    </Button>
                </Box>
            ) : (
                <>
                    <Typography variant="h6" gutterBottom>
                        Order Summary:
                    </Typography>
                    {cart && cart.length > 0 ? (
                        cart.map((item) => (
                            <Typography key={item.id}>
                                {item.name} - Quantity: {item.quantity} - Price: ${item.sellingPrice?.toFixed(2)}
                            </Typography>
                        ))
                    ) : (
                        <Typography variant="body1">No items in cart.</Typography>
                    )}
                    <Box mt={4}>
                        <Typography variant="h6">Payment Options:</Typography>
                        <Button variant="contained" color="primary" onClick={() => handlePayment('Cash')} sx={{ mt: 2 }}>
                            Pay with Cash
                        </Button>
                        {/* Add more payment options if needed */}
                    </Box>
                </>
            )}
        </Container>
    );
};

export default PlaceOrder;

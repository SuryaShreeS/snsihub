import React from 'react';
import { Container, Typography, List, ListItem, ListItemText } from '@mui/material';

const OrderSummary = ({ order }) => (
    <Container maxWidth="sm">
        <Typography variant="h4" sx={{ marginBottom: 4 }}>
            Order Summary
        </Typography>
        <List>
            {order.items.map((item) => (
                <ListItem key={item.id}>
                    <ListItemText primary={item.name} secondary={`₹${item.sellingPrice}`} />
                </ListItem>
            ))}
        </List>
        <Typography variant="h6" sx={{ marginTop: 4 }}>
            Total: ₹{order.total}
        </Typography>
        <Typography variant="body1" sx={{ marginTop: 2 }}>
            Payment Method: Cash
        </Typography>
    </Container>
);

export default OrderSummary;

import React from 'react';
import { AppBar, Toolbar, Typography, Badge,Button } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/slices/AuthSlice';

const Navbar = ({ cartCount }) => {
    const dispatch = useDispatch();
    const { isLoggedIn } = useSelector((state) => state.auth);

    const handleLogout = () => {
        dispatch(logout());
    };

    return (
        <AppBar position="static">
            <Toolbar>
                <Typography variant="h6" component={Link} to="/" sx={{ flexGrow: 1, textDecoration: 'none', color: 'inherit' }}>
                    E-Commerce
                </Typography>
                {isLoggedIn ? (
                    <>
                        <Button color="inherit" component={Link} to="/order-summary">
                            My Orders
                        </Button>
                        <Button color="inherit" onClick={handleLogout}>
                            Logout
                        </Button>
                    </>
                ) : (
                    <>
                        <Button color="inherit" component={Link} to="/login">
                            Login
                        </Button>
                        <Button color="inherit" component={Link} to="/signup">
                            Signup
                        </Button>
                    </>
                )}
                 <Typography variant="h6" style={{ flexGrow: 1 }}>
                    Product Store
                </Typography>
                <Badge badgeContent={cartCount} color="secondary">
                    <ShoppingCartIcon />
                </Badge>
            </Toolbar>
        </AppBar>
    );
};

export default Navbar;
